// LoopDoc Client Application

const state = {
  ws: null,
  clientId: null,
  user: null,
  currentDoc: null,
  documents: [],
  agents: [],
  viewMode: 'hybrid',
  selectedBlockType: 'paragraph',
  expandedThreads: new Set()
};

const elements = {
  docList: document.getElementById('doc-list'),
  agentList: document.getElementById('agent-list'),
  userInfo: document.getElementById('user-info'),
  emptyState: document.getElementById('empty-state'),
  documentView: document.getElementById('document-view'),
  blocksContainer: document.getElementById('blocks-container'),
  docTitle: document.getElementById('doc-title'),
  blockInput: document.getElementById('block-input'),
  addBlockBtn: document.getElementById('add-block-btn'),
  newDocBtn: document.getElementById('new-doc-btn'),
  viewBtns: document.querySelectorAll('.view-btn'),
  typeBtns: document.querySelectorAll('.type-btn')
};

// Initialize
function init() {
  connectWebSocket();
  setupEventListeners();
  generateUser();
}

function generateUser() {
  const names = ['Alex', 'Jordan', 'Taylor', 'Morgan', 'Casey', 'Riley', 'Quinn'];
  const avatars = ['👤', '🧑', '👩', '🧔', '👱', '🧑‍🦱', '👩‍🦰'];
  const randomIdx = Math.floor(Math.random() * names.length);
  
  state.user = {
    id: `user_${Date.now()}`,
    name: names[randomIdx],
    avatar: avatars[randomIdx]
  };
  
  updateUserInfo();
}

function updateUserInfo() {
  elements.userInfo.innerHTML = `
    <span class="avatar">${state.user.avatar}</span>
    <span class="name">${state.user.name}</span>
  `;
}

// WebSocket
function connectWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}`;
  
  state.ws = new WebSocket(wsUrl);
  
  state.ws.onopen = () => {
    sendMessage({
      type: 'auth',
      userId: state.user.id,
      name: state.user.name,
      avatar: state.user.avatar
    });
  };
  
  state.ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    handleServerMessage(msg);
  };
  
  state.ws.onclose = () => {
    setTimeout(connectWebSocket, 3000);
  };
}

function sendMessage(data) {
  if (state.ws?.readyState === WebSocket.OPEN) {
    state.ws.send(JSON.stringify(data));
  }
}

// Message Handlers
function handleServerMessage(msg) {
  switch (msg.type) {
    case 'init':
      state.clientId = msg.data.clientId;
      state.documents = msg.data.documents;
      state.agents = msg.data.agents;
      renderDocList();
      renderAgentList();
      break;
      
    case 'auth_success':
      state.user = msg.user;
      updateUserInfo();
      break;
      
    case 'document_loaded':
      loadDocument(msg.document);
      break;
      
    case 'block_added':
      if (state.currentDoc?.id === msg.block.docId) {
        addBlockToView(msg.block);
      }
      break;
      
    case 'block_updated':
      updateBlockInView(msg.block);
      break;
      
    case 'reply_added':
      addReplyToBlock(msg.blockId, msg.reply);
      break;
      
    case 'view_mode_changed':
      setViewMode(msg.mode);
      break;
  }
}

// Document Management
function loadDocument(doc) {
  state.currentDoc = doc;
  state.viewMode = doc.viewMode || 'hybrid';
  
  // Hide empty state, show document
  elements.emptyState.classList.add('hidden');
  elements.documentView.classList.remove('hidden');
  
  // Update title
  elements.docTitle.value = doc.title;
  
  // Update view mode buttons
  updateViewButtons();
  
  // Render blocks
  renderBlocks();
  
  // Update sidebar selection
  document.querySelectorAll('.doc-item').forEach(el => {
    el.classList.toggle('active', el.dataset.id === doc.id);
  });
}

function renderDocList() {
  elements.docList.innerHTML = state.documents.map(doc => `
    <li class="doc-item ${doc.id === state.currentDoc?.id ? 'active' : ''}" 
        data-id="${doc.id}"
        onclick="joinDocument('${doc.id}')">
      <span class="icon">📄</span>
      <div class="info">
        <span class="name">${escapeHtml(doc.title)}</span>
        <span class="meta">${doc.blockCount} blocks • ${doc.participantCount} participants</span>
      </div>
    </li>
  `).join('');
}

function renderAgentList() {
  elements.agentList.innerHTML = state.agents.map(agent => `
    <li class="agent-item" title="${agent.capabilities.join(', ')}">
      <span class="avatar">${agent.avatar}</span>
      <div class="info">
        <span class="name" style="color: ${agent.color}">${escapeHtml(agent.name)}</span>
        <span class="role">${agent.capabilities[0]}</span>
      </div>
      <span class="status"></span>
    </li>
  `).join('');
}

function renderBlocks() {
  if (!state.currentDoc) return;
  
  elements.blocksContainer.innerHTML = state.currentDoc.blocks
    .sort((a, b) => a.order - b.order)
    .map(block => renderBlock(block))
    .join('');
  
  // Apply view mode
  setViewMode(state.viewMode);
}

function renderBlock(block) {
  const hasReplies = block.replies?.length > 0;
  const isExpanded = state.expandedThreads.has(block.id);
  const isAgent = block.author?.type === 'agent';
  
  let contentHtml = '';
  
  switch (block.type) {
    case 'heading':
      contentHtml = `<h2 class="block-content" contenteditable="true" onblur="updateBlock('${block.id}', this.innerText)">${escapeHtml(block.content)}</h2>`;
      break;
    case 'task':
      contentHtml = `
        <div style="display: flex; align-items: flex-start; gap: 10px;">
          <div class="task-checkbox ${block.checked ? 'checked' : ''}" onclick="toggleTask('${block.id}', ${!block.checked})"></div>
          <div class="block-content ${block.checked ? 'checked' : ''}" contenteditable="true" onblur="updateBlock('${block.id}', this.innerText)">${escapeHtml(block.content)}</div>
        </div>
      `;
      break;
    case 'discussion':
      contentHtml = `<div class="block-content" contenteditable="true" onblur="updateBlock('${block.id}', this.innerText)">${escapeHtml(block.content)}</div>`;
      break;
    default:
      contentHtml = `<div class="block-content" contenteditable="true" onblur="updateBlock('${block.id}', this.innerText)">${escapeHtml(block.content)}</div>`;
  }
  
  const time = new Date(block.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  return `
    <div class="block ${block.type}" data-id="${block.id}">
      <div class="block-content-wrapper">
        <div class="block-handle">
          <span class="drag-icon">⋮⋮</span>
          <button class="thread-toggle ${hasReplies ? 'has-replies' : ''}" onclick="toggleThread('${block.id}')">
            ${hasReplies ? block.replies.length : '+'}
          </button>
        </div>
        <div class="block-main">
          <div class="block-header">
            <span class="block-author ${isAgent ? 'agent' : ''}">${block.author?.name || 'Unknown'}</span>
            <span class="block-time">${time}</span>
            ${isAgent ? '<span style="color: var(--accent-primary); font-size: 0.75rem;">🤖 Agent</span>' : ''}
          </div>
          ${contentHtml}
        </div>
      </div>
      
      ${(isExpanded || state.viewMode === 'chat') && hasReplies ? `
        <div class="thread-container">
          ${block.replies.map(reply => renderReply(reply)).join('')}
          ${renderReplyInput(block.id)}
        </div>
      ` : ''}
      
      ${!isExpanded && state.viewMode !== 'chat' ? renderReplyInput(block.id, true) : ''}
    </div>
  `;
}

function renderReply(reply) {
  const isAgent = reply.author?.type === 'agent';
  const time = new Date(reply.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  return `
    <div class="reply">
      <span class="avatar">${reply.author?.avatar || '👤'}</span>
      <div class="reply-content">
        <div class="reply-header">
          <span class="reply-author ${isAgent ? 'agent' : ''}">${reply.author?.name || 'Unknown'}</span>
          <span class="reply-time">${time}</span>
          ${reply.isAgentAction ? '<span style="color: var(--success); font-size: 0.75rem;">✓ Action</span>' : ''}
        </div>
        <div class="reply-text">${formatContent(reply.content)}</div>
      </div>
    </div>
  `;
}

function renderReplyInput(blockId, collapsed = false) {
  if (collapsed) {
    return `
      <div class="reply-input-container" style="padding: 8px 0;">
        <input type="text" 
               class="reply-input" 
               placeholder="Reply to this block..."
               style="min-height: 36px; padding: 8px 12px; font-size: 0.85rem;"
               onkeydown="if(event.key==='Enter') addReply('${blockId}', this.value); if(event.key==='Enter') this.value='';"
        >
      </div>
    `;
  }
  
  return `
    <div class="reply-input-container">
      <span class="avatar">${state.user.avatar}</span>
      <textarea class="reply-input" 
                placeholder="Add to the discussion... (use @ to mention agents)"
                rows="1"
                onkeydown="handleReplyKeydown(event, '${blockId}', this)"
                oninput="this.style.height='auto'; this.style.height=Math.min(this.scrollHeight, 100)+'px'"
      ></textarea>
      <button class="reply-submit" onclick="submitReply('${blockId}', this.parentElement.querySelector('textarea'))">Reply</button>
    </div>
  `;
}

function formatContent(content) {
  return escapeHtml(content)
    .replace(/@(\w+)/g, '<span class="agent-mention">@$1</span>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br>');
}

// Actions
function joinDocument(docId) {
  sendMessage({
    type: 'join_document',
    docId
  });
}

function toggleThread(blockId) {
  if (state.expandedThreads.has(blockId)) {
    state.expandedThreads.delete(blockId);
  } else {
    state.expandedThreads.add(blockId);
  }
  renderBlocks();
}

function setViewMode(mode) {
  state.viewMode = mode;
  elements.blocksContainer.className = `blocks-container view-${mode}`;
  updateViewButtons();
}

function updateViewButtons() {
  elements.viewBtns.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.mode === state.viewMode);
  });
}

function toggleTask(blockId, checked) {
  sendMessage({
    type: 'update_block',
    docId: state.currentDoc.id,
    blockId,
    checked
  });
}

function updateBlock(blockId, content) {
  sendMessage({
    type: 'update_block',
    docId: state.currentDoc.id,
    blockId,
    content
  });
}

function addBlock() {
  const content = elements.blockInput.value.trim();
  if (!content || !state.currentDoc) return;
  
  sendMessage({
    type: 'add_block',
    docId: state.currentDoc.id,
    blockType: state.selectedBlockType,
    content
  });
  
  elements.blockInput.value = '';
  elements.blockInput.style.height = 'auto';
}

function addReply(blockId, content) {
  if (!content.trim()) return;
  
  sendMessage({
    type: 'add_reply',
    docId: state.currentDoc.id,
    blockId,
    content
  });
}

function submitReply(blockId, textarea) {
  const content = textarea.value.trim();
  if (!content) return;
  
  addReply(blockId, content);
  textarea.value = '';
  textarea.style.height = 'auto';
}

function handleReplyKeydown(event, blockId, textarea) {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    submitReply(blockId, textarea);
  }
}

function addBlockToView(block) {
  if (!state.currentDoc) return;
  state.currentDoc.blocks.push(block);
  
  const html = renderBlock(block);
  elements.blocksContainer.insertAdjacentHTML('beforeend', html);
  scrollToBottom();
}

function updateBlockInView(updatedBlock) {
  if (!state.currentDoc) return;
  
  const idx = state.currentDoc.blocks.findIndex(b => b.id === updatedBlock.id);
  if (idx !== -1) {
    state.currentDoc.blocks[idx] = updatedBlock;
    
    // Re-render just this block
    const blockEl = document.querySelector(`.block[data-id="${updatedBlock.id}"]`);
    if (blockEl) {
      blockEl.outerHTML = renderBlock(updatedBlock);
    }
  }
}

function addReplyToBlock(blockId, reply) {
  if (!state.currentDoc) return;
  
  const block = state.currentDoc.blocks.find(b => b.id === blockId);
  if (block) {
    if (!block.replies) block.replies = [];
    block.replies.push(reply);
    
    // Expand thread to show new reply
    state.expandedThreads.add(blockId);
    
    // Re-render this block
    const blockEl = document.querySelector(`.block[data-id="${blockId}"]`);
    if (blockEl) {
      blockEl.outerHTML = renderBlock(block);
    }
  }
}

function scrollToBottom() {
  elements.blocksContainer.scrollTop = elements.blocksContainer.scrollHeight;
}

// Event Listeners
function setupEventListeners() {
  // Add block
  elements.addBlockBtn.addEventListener('click', addBlock);
  
  elements.blockInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      addBlock();
    }
  });
  
  elements.blockInput.addEventListener('input', () => {
    elements.blockInput.style.height = 'auto';
    elements.blockInput.style.height = Math.min(elements.blockInput.scrollHeight, 200) + 'px';
  });
  
  // View mode toggle
  elements.viewBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const mode = btn.dataset.mode;
      sendMessage({
        type: 'toggle_view_mode',
        docId: state.currentDoc?.id,
        mode
      });
    });
  });
  
  // Block type selector
  elements.typeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      state.selectedBlockType = btn.dataset.type;
      elements.typeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      // Update placeholder
      const placeholders = {
        paragraph: 'Type / for commands, @ to mention agents...',
        heading: 'Heading text...',
        task: 'Task description...',
        discussion: 'Start a discussion...'
      };
      elements.blockInput.placeholder = placeholders[state.selectedBlockType];
    });
  });
  
  // New document
  elements.newDocBtn.addEventListener('click', () => {
    const title = prompt('Document title:');
    if (title) {
      // In a real app, this would create a new document
      alert('New document creation would happen here!');
    }
  });
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Expose functions to global scope
window.joinDocument = joinDocument;
window.toggleThread = toggleThread;
window.toggleTask = toggleTask;
window.updateBlock = updateBlock;
window.addReply = addReply;
window.submitReply = submitReply;
window.handleReplyKeydown = handleReplyKeydown;

// Start
init();
