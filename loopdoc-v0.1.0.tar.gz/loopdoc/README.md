# LoopDoc 🔄

> **Where documents are conversations and conversations are documents.**

LoopDoc is a unified workspace that merges the best of document editing and team messaging. Every block in a document can have threaded discussions. Every conversation can be structured into a document. AI agents participate as first-class collaborators in both.

## 🌟 The Merge: Why This Matters

### The Problem with Today's Tools

**Traditional Documents (Notion, Google Docs):**
- Comments are sidebars, not part of the document
- Discussions get lost or resolved away
- No real-time chat feel
- AI is an afterthought (sidebar assistant)

**Traditional Messaging (Slack, Discord):**
- Conversations scroll away and are lost
- Hard to find decisions and action items
- No structured document view
- Bots are second-class participants

### LoopDoc's Unified Approach

```
┌─────────────────────────────────────────────────────────────┐
│                    LoopDoc Unified Model                     │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│   DOCUMENT VIEW          HYBRID VIEW           CHAT VIEW    │
│                                                              │
│   ## Goals               ## Goals              Alex:        │
│                          💬 [3 replies]        Let's plan   │
│   • Task 1               • Task 1 ☐          Q1 roadmap    │
│   • Task 2 ☐             • Task 2 ☑          Sarah:        │
│                          💬 [1 reply]          Agreed!      │
│   💬 Discussion          💬 Discussion:        Claude:      │
│      [5 replies]         Sarah: What about...  I suggest... │
│                          Alex: Good point                   │
│                          Claude: Analysis...                │
│                                                              │
│   ← Structured           ← Best of both       ← Free-form   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## 🚀 Features

### Core Concepts

1. **Threaded Block Discussions**
   - Every block (paragraph, heading, task) has threaded replies
   - Discussions are part of the document, not sidebars
   - Toggle threads open/closed per block

2. **Three View Modes**
   - **Document**: Clean, structured view (like Notion)
   - **Chat**: Linear conversation view (like Slack)
   - **Hybrid**: Blocks with inline discussions visible

3. **Agent Collaboration**
   - Agents are first-class participants
   - They can edit blocks, reply in threads, and take actions
   - Mention agents with @ to get their assistance

4. **Fluid Transformation**
   - Start messy (chat mode), end structured (doc mode)
   - Promote discussions to standalone documents
   - Extract action items from conversations

### Built-in Agents

| Agent | Role | Capabilities |
|-------|------|--------------|
| **Claude** | 🤖 General Assistant | Edit, discuss, summarize, answer questions |
| **Scribe** | 📝 Document Organizer | Structure, extract, organize content |
| **Synthesizer** | 🔮 Insights Engine | Summarize, connect ideas, find patterns |

## 🛠️ Quick Start

### Prerequisites

- Node.js 18+
- npm

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/loopdoc.git
cd loopdoc

# Install dependencies
npm install

# Start the server
npm run dev
```

Open http://localhost:3000 in your browser.

### First Steps

1. **Select the sample document** "Q1 Product Roadmap" from the sidebar
2. **Explore the three view modes** using the toggle in the header
3. **Click the + button** on any block to expand its discussion thread
4. **Add a reply** to any block's thread
5. **Try mentioning an agent** with @Claude in a reply
6. **Add new blocks** using the input area at the bottom

## 📖 Usage Guide

### Working with Blocks

- **Add a block**: Select type (Text, Heading, Task, Discussion) and type in the input area
- **Edit a block**: Click any block content and start typing
- **Toggle thread**: Click the + button on the left of any block
- **Complete a task**: Click the checkbox on task blocks

### View Modes

| Mode | Best For | Shows |
|------|----------|-------|
| **Document** | Reading, presenting | Clean blocks only |
| **Hybrid** | Working, collaborating | Blocks + visible threads |
| **Chat** | Brainstorming, discovery | Linear conversation flow |

### Agent Interactions

Mention agents in any reply:

- `@Claude summarize this` - Get a summary of the document or thread
- `@Claude help` - See what Claude can do
- `@Scribe organize this` - Get structure suggestions
- `@Synthesizer analyze` - Get insights from discussions

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        LoopDoc                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   ┌─────────────┐      ┌─────────────┐      ┌─────────────┐    │
│   │   Client    │◄────►│  WebSocket  │◄────►│   Server    │    │
│   │  (Unified)  │      │   Gateway   │      │   Engine    │    │
│   └──────┬──────┘      └─────────────┘      └──────┬──────┘    │
│          │                                          │           │
│          └──────────────────┬───────────────────────┘           │
│                             ▼                                   │
│   ┌─────────────────────────────────────────────────────┐      │
│   │              Unified Data Model                      │      │
│   │  ┌─────────────────────────────────────────────┐   │      │
│   │  │  Block = Document Unit + Message             │   │      │
│   │  │  • Content (text, heading, task, etc.)       │   │      │
│   │  │  • Author (human or agent)                   │   │      │
│   │  │  • Thread (replies/discussions)              │   │      │
│   │  │  • Order (document structure)                │   │      │
│   │  └─────────────────────────────────────────────┘   │      │
│   └─────────────────────────────────────────────────────┘      │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 🗺️ Roadmap

### Phase 1: Foundation (Current)
- [x] Unified block + thread data model
- [x] Three view modes (Doc, Chat, Hybrid)
- [x] Simulated agent responses
- [x] Real-time collaboration via WebSocket

### Phase 2: Intelligence
- [ ] Real LLM integration (OpenAI, Anthropic)
- [ ] Agent memory across sessions
- [ ] Smart suggestions as you type
- [ ] Auto-extraction of action items

### Phase 3: Collaboration
- [ ] Multiple simultaneous editors
- [ ] Cursor presence
- [ ] Permissions and sharing
- [ ] Comments vs discussions distinction

### Phase 4: Power Features
- [ ] Database blocks (like Notion)
- [ ] Templates and workflows
- [ ] GitHub integration (sync docs to repos)
- [ ] API for external agents

## 🤔 Design Philosophy

### 1. Documents and Conversations Are the Same Thing

A meeting transcript IS a document. A requirements doc IS a conversation. The distinction is artificial. LoopDoc lets you work in whichever mode fits your current thinking.

### 2. Context Should Never Be Lost

In traditional tools, when you resolve a comment, it's gone. In LoopDoc, discussions become part of the document history. You can always see how decisions were made.

### 3. Agents Are Team Members

Agents aren't tools you use—they're collaborators you work with. They have opinions, can be wrong, and improve over time. They participate in threads just like humans.

### 4. Structure Emerges from Chaos

Don't force structure prematurely. Start with free-form chat, let agents help organize, gradually solidify into a document. The tool adapts to your workflow, not the other way around.

## 🎨 The Unified Product Vision

```
┌─────────────────────────────────────────────────────────────────┐
│                     The LoopDoc Ecosystem                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐      │
│  │   GitHub     │    │   LoopDoc    │    │   Agents     │      │
│  │   Repos      │◄──►│   Workspace  │◄──►│   (Claude,   │      │
│  │              │    │              │    │   Custom)    │      │
│  └──────────────┘    └──────┬───────┘    └──────────────┘      │
│                             │                                   │
│         ┌───────────────────┼───────────────────┐              │
│         ▼                   ▼                   ▼              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐      │
│  │   Documents  │    │   Threads    │    │   Actions    │      │
│  │   (Structured)│   │   (Fluid)    │    │   (Executed) │      │
│  └──────────────┘    └──────────────┘    └──────────────┘      │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 🙏 Acknowledgments

- **OpenClaw** for the philosophy of persistent, file-based agent memory
- **Notion** for pioneering block-based editing
- **Linear** for showing how threaded discussions can be elegant
- **Roam Research** for demonstrating that documents can be graphs

## 📄 License

MIT License - see LICENSE file for details.

## 🔮 The Future

LoopDoc is an experiment in what work looks like when AI agents are true collaborators. As agents become more capable, the tools we use to work with them must evolve. LoopDoc is a step toward that future—a place where humans and agents think together.

---

**Built with 🔄 for the future of collaboration.**
