import { WebSocketServer } from 'ws';
import { v4 as uuidv4 } from 'uuid';
import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;

// In-memory storage
const documents = new Map();
const clients = new Map();

// Agent definitions
const agents = new Map([
  ['claude', {
    id: 'claude',
    name: 'Claude',
    type: 'agent',
    avatar: '🤖',
    color: '#6366f1',
    capabilities: ['edit', 'discuss', 'summarize', 'transform'],
    status: 'online'
  }],
  ['scribe', {
    id: 'scribe',
    name: 'Scribe',
    type: 'agent',
    avatar: '📝',
    color: '#22c55e',
    capabilities: ['structure', 'extract', 'organize'],
    status: 'online'
  }],
  ['synthesizer', {
    id: 'synthesizer',
    name: 'Synthesizer',
    type: 'agent',
    avatar: '🔮',
    color: '#f59e0b',
    capabilities: ['summarize', 'connect', 'insights'],
    status: 'online'
  }]
]);

// Initialize with sample document
const sampleDocId = uuidv4();
const sampleBlocks = [
  {
    id: uuidv4(),
    type: 'heading',
    content: 'Q1 Product Roadmap',
    author: { id: 'user1', name: 'Alex', avatar: '👤', type: 'human' },
    createdAt: new Date().toISOString(),
    order: 0,
    threadId: uuidv4(),
    replies: []
  },
  {
    id: uuidv4(),
    type: 'paragraph',
    content: 'Our focus for Q1 is on improving user onboarding and launching the mobile app.',
    author: { id: 'user1', name: 'Alex', avatar: '👤', type: 'human' },
    createdAt: new Date().toISOString(),
    order: 1,
    threadId: uuidv4(),
    replies: [
      {
        id: uuidv4(),
        content: 'Should we also consider tablet support for the mobile app?',
        author: { id: 'user2', name: 'Sarah', avatar: '👩', type: 'human' },
        timestamp: new Date().toISOString()
      },
      {
        id: uuidv4(),
        content: 'Good point! I\'ll add that as a consideration.',
        author: { id: 'user1', name: 'Alex', avatar: '👤', type: 'human' },
        timestamp: new Date().toISOString()
      }
    ]
  },
  {
    id: uuidv4(),
    type: 'task',
    content: 'Research competitor onboarding flows',
    checked: false,
    author: { id: 'claude', name: 'Claude', avatar: '🤖', type: 'agent' },
    createdAt: new Date().toISOString(),
    order: 2,
    threadId: uuidv4(),
    replies: []
  },
  {
    id: uuidv4(),
    type: 'task',
    content: 'Design mobile app wireframes',
    checked: true,
    author: { id: 'user2', name: 'Sarah', avatar: '👩', type: 'human' },
    createdAt: new Date().toISOString(),
    order: 3,
    threadId: uuidv4(),
    replies: [
      {
        id: uuidv4(),
        content: '✅ Completed - designs are in Figma',
        author: { id: 'user2', name: 'Sarah', avatar: '👩', type: 'human' },
        timestamp: new Date().toISOString()
      }
    ]
  },
  {
    id: uuidv4(),
    type: 'discussion',
    content: 'Open discussion: What features should we prioritize for the mobile launch?',
    author: { id: 'user1', name: 'Alex', avatar: '👤', type: 'human' },
    createdAt: new Date().toISOString(),
    order: 4,
    threadId: uuidv4(),
    replies: [
      {
        id: uuidv4(),
        content: 'I think offline mode is critical for mobile users',
        author: { id: 'user2', name: 'Sarah', avatar: '👩', type: 'human' },
        timestamp: new Date().toISOString()
      },
      {
        id: uuidv4(),
        content: 'Agreed! Also push notifications for important updates.',
        author: { id: 'user3', name: 'Jordan', avatar: '🧑', type: 'human' },
        timestamp: new Date().toISOString()
      },
      {
        id: uuidv4(),
        content: 'I can help analyze which features have the highest user demand. Should I compile a report?',
        author: { id: 'claude', name: 'Claude', avatar: '🤖', type: 'agent' },
        timestamp: new Date().toISOString()
      }
    ]
  }
];

documents.set(sampleDocId, {
  id: sampleDocId,
  title: 'Q1 Product Roadmap',
  type: 'hybrid',
  viewMode: 'hybrid',
  blocks: sampleBlocks,
  participants: [
    { id: 'user1', name: 'Alex', avatar: '👤', type: 'human' },
    { id: 'user2', name: 'Sarah', avatar: '👩', type: 'human' },
    { id: 'user3', name: 'Jordan', avatar: '🧑', type: 'human' },
    agents.get('claude')
  ],
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString()
});

// HTTP server
const server = http.createServer((req, res) => {
  let filePath = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url);
  
  const ext = path.extname(filePath);
  const contentTypes = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json'
  };
  
  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404);
        res.end('Not Found');
      } else {
        res.writeHead(500);
        res.end('Server Error');
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentTypes[ext] || 'text/plain' });
      res.end(content);
    }
  });
});

// WebSocket server
const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  const clientId = uuidv4();
  console.log(`Client connected: ${clientId}`);
  
  clients.set(clientId, {
    ws,
    id: clientId,
    user: null,
    currentDoc: null
  });

  // Send initial data
  ws.send(JSON.stringify({
    type: 'init',
    data: {
      clientId,
      documents: Array.from(documents.values()).map(d => ({
        id: d.id,
        title: d.title,
        type: d.type,
        updatedAt: d.updatedAt,
        participantCount: d.participants.length,
        blockCount: d.blocks.length
      })),
      agents: Array.from(agents.values())
    }
  }));

  ws.on('message', async (data) => {
    try {
      const msg = JSON.parse(data);
      await handleMessage(clientId, msg);
    } catch (err) {
      console.error('Message handling error:', err);
      sendToClient(clientId, { type: 'error', error: err.message });
    }
  });

  ws.on('close', () => {
    clients.delete(clientId);
  });
});

async function handleMessage(clientId, msg) {
  const client = clients.get(clientId);
  
  switch (msg.type) {
    case 'auth':
      client.user = {
        id: msg.userId || uuidv4(),
        name: msg.name || 'Anonymous',
        type: 'human',
        avatar: msg.avatar || '👤'
      };
      sendToClient(clientId, { type: 'auth_success', user: client.user });
      break;

    case 'join_document':
      client.currentDoc = msg.docId;
      const doc = documents.get(msg.docId);
      if (doc) {
        sendToClient(clientId, {
          type: 'document_loaded',
          document: doc
        });
      }
      break;

    case 'add_block':
      await handleAddBlock(client, msg);
      break;

    case 'update_block':
      await handleUpdateBlock(client, msg);
      break;

    case 'add_reply':
      await handleAddReply(client, msg);
      break;

    case 'toggle_view_mode':
      await handleToggleViewMode(client, msg);
      break;

    case 'promote_to_doc':
      await handlePromoteToDoc(client, msg);
      break;

    case 'agent_action':
      await handleAgentAction(client, msg);
      break;

    case 'mention_agent':
      await handleAgentMention(client, msg);
      break;
  }
}

async function handleAddBlock(client, msg) {
  const doc = documents.get(msg.docId);
  if (!doc) return;

  const newBlock = {
    id: uuidv4(),
    type: msg.blockType || 'paragraph',
    content: msg.content,
    author: client.user,
    createdAt: new Date().toISOString(),
    order: doc.blocks.length,
    threadId: uuidv4(),
    replies: []
  };

  if (msg.blockType === 'task') {
    newBlock.checked = false;
  }

  doc.blocks.push(newBlock);
  doc.updatedAt = new Date().toISOString();

  broadcastToDoc(msg.docId, {
    type: 'block_added',
    block: newBlock
  });
}

async function handleUpdateBlock(client, msg) {
  const doc = documents.get(msg.docId);
  if (!doc) return;

  const block = doc.blocks.find(b => b.id === msg.blockId);
  if (!block) return;

  if (msg.content !== undefined) block.content = msg.content;
  if (msg.checked !== undefined) block.checked = msg.checked;
  block.updatedAt = new Date().toISOString();

  broadcastToDoc(msg.docId, {
    type: 'block_updated',
    block
  });
}

async function handleAddReply(client, msg) {
  const doc = documents.get(msg.docId);
  if (!doc) return;

  const block = doc.blocks.find(b => b.id === msg.blockId);
  if (!block) return;

  const reply = {
    id: uuidv4(),
    content: msg.content,
    author: client.user,
    timestamp: new Date().toISOString()
  };

  block.replies.push(reply);
  doc.updatedAt = new Date().toISOString();

  broadcastToDoc(msg.docId, {
    type: 'reply_added',
    blockId: block.id,
    reply
  });

  // Check for agent mentions
  await checkAgentMentions(doc, block, reply);
}

async function handleToggleViewMode(client, msg) {
  const doc = documents.get(msg.docId);
  if (!doc) return;

  doc.viewMode = msg.mode;
  
  broadcastToDoc(msg.docId, {
    type: 'view_mode_changed',
    mode: msg.mode
  });
}

async function handlePromoteToDoc(client, msg) {
  // Convert a discussion thread into a structured document
  const doc = documents.get(msg.docId);
  if (!doc) return;

  const discussionBlock = doc.blocks.find(b => b.id === msg.blockId);
  if (!discussionBlock || discussionBlock.type !== 'discussion') return;

  // Create new document from discussion
  const newDocId = uuidv4();
  const extractedBlocks = [
    {
      id: uuidv4(),
      type: 'heading',
      content: `Extracted: ${discussionBlock.content.substring(0, 50)}...`,
      author: client.user,
      createdAt: new Date().toISOString(),
      order: 0,
      threadId: uuidv4(),
      replies: []
    },
    ...discussionBlock.replies.map((reply, idx) => ({
      id: uuidv4(),
      type: 'paragraph',
      content: `${reply.author.name}: ${reply.content}`,
      author: reply.author,
      createdAt: reply.timestamp,
      order: idx + 1,
      threadId: uuidv4(),
      replies: []
    }))
  ];

  const newDoc = {
    id: newDocId,
    title: `Extracted Discussion`,
    type: 'document',
    viewMode: 'doc',
    blocks: extractedBlocks,
    participants: doc.participants,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    parentDocId: doc.id,
    parentBlockId: discussionBlock.id
  };

  documents.set(newDocId, newDoc);

  // Add reference block to original doc
  const refBlock = {
    id: uuidv4(),
    type: 'reference',
    content: `📄 Extracted to document: ${newDoc.title}`,
    refDocId: newDocId,
    author: client.user,
    createdAt: new Date().toISOString(),
    order: discussionBlock.order + 1,
    threadId: uuidv4(),
    replies: []
  };

  doc.blocks.splice(discussionBlock.order + 1, 0, refBlock);
  doc.updatedAt = new Date().toISOString();

  broadcastToDoc(msg.docId, {
    type: 'document_extracted',
    newDoc: {
      id: newDoc.id,
      title: newDoc.title,
      type: newDoc.type
    },
    refBlock
  });
}

async function handleAgentAction(client, msg) {
  const doc = documents.get(msg.docId);
  if (!doc) return;

  const agent = agents.get(msg.agentId);
  if (!agent) return;

  let result;
  
  switch (msg.action) {
    case 'summarize':
      result = await generateSummary(doc, msg.blockId);
      break;
    case 'structure':
      result = await generateStructure(doc);
      break;
    case 'extract_tasks':
      result = await extractTasks(doc);
      break;
    default:
      result = `Action "${msg.action}" completed by ${agent.name}`;
  }

  // Add agent response as a block or reply
  if (msg.blockId) {
    const block = doc.blocks.find(b => b.id === msg.blockId);
    if (block) {
      block.replies.push({
        id: uuidv4(),
        content: result,
        author: agent,
        timestamp: new Date().toISOString(),
        isAgentAction: true,
        action: msg.action
      });

      broadcastToDoc(msg.docId, {
        type: 'reply_added',
        blockId: block.id,
        reply: block.replies[block.replies.length - 1]
      });
    }
  }
}

async function handleAgentMention(client, msg) {
  const doc = documents.get(msg.docId);
  if (!doc) return;

  const agent = agents.get(msg.agentId);
  if (!agent) return;

  const block = doc.blocks.find(b => b.id === msg.blockId);
  if (!block) return;

  // Generate contextual response
  const response = await generateAgentResponse(agent, msg.content, block, doc);

  setTimeout(() => {
    const reply = {
      id: uuidv4(),
      content: response,
      author: agent,
      timestamp: new Date().toISOString(),
      isAgentMention: true
    };

    block.replies.push(reply);
    doc.updatedAt = new Date().toISOString();

    broadcastToDoc(msg.docId, {
      type: 'reply_added',
      blockId: block.id,
      reply
    });
  }, 1000 + Math.random() * 1500);
}

async function checkAgentMentions(doc, block, reply) {
  const content = reply.content.toLowerCase();
  
  for (const [agentId, agent] of agents) {
    if (content.includes(`@${agentId}`) || content.includes(`@${agent.name.toLowerCase()}`)) {
      const response = await generateAgentResponse(agent, reply.content, block, doc);
      
      setTimeout(() => {
        const agentReply = {
          id: uuidv4(),
          content: response,
          author: agent,
          timestamp: new Date().toISOString(),
          isAgentMention: true
        };

        block.replies.push(agentReply);
        doc.updatedAt = new Date().toISOString();

        broadcastToDoc(doc.id, {
          type: 'reply_added',
          blockId: block.id,
          reply: agentReply
        });
      }, 1000 + Math.random() * 1500);
    }
  }
}

async function generateAgentResponse(agent, content, block, doc) {
  const lowerContent = content.toLowerCase();
  
  if (agent.id === 'claude') {
    if (lowerContent.includes('summarize')) {
      const blockCount = doc.blocks.length;
      const replyCount = doc.blocks.reduce((sum, b) => sum + (b.replies?.length || 0), 0);
      return `📋 **Document Summary**\n\nThis document has ${blockCount} blocks with ${replyCount} discussion replies. Key topics include: ${doc.blocks.filter(b => b.type === 'heading').map(b => b.content).join(', ')}.`;
    }
    if (lowerContent.includes('help') || lowerContent.includes('what')) {
      return `I'm here to help! I can:\n• Summarize this document\n• Suggest improvements to blocks\n• Answer questions about the content\n• Help structure messy discussions\n\nWhat would you like me to do?`;
    }
    if (block.type === 'task') {
      return `I can help with this task. Would you like me to:\n• Break it down into subtasks\n• Suggest an approach\n• Find related tasks in this doc`;
    }
    return `Thanks for the mention! I see this is a ${block.type} block. How can I assist with this?`;
  }
  
  if (agent.id === 'scribe') {
    if (lowerContent.includes('organize') || lowerContent.includes('structure')) {
      return `📝 **Organization Suggestions**\n\nLooking at this document, I suggest:\n1. Group related tasks under headings\n2. Convert the discussion block to a decision log\n3. Add a "Resources" section at the end`;
    }
    return `I can help organize this content. Would you like me to suggest a structure or extract action items?`;
  }
  
  if (agent.id === 'synthesizer') {
    if (block.replies && block.replies.length > 2) {
      return `🔮 **Discussion Insights**\n\nBased on the ${block.replies.length} replies in this thread:\n• Common theme: Collaboration and planning\n• Open questions: 2\n• Suggested next step: Schedule a follow-up meeting`;
    }
    return `I can analyze patterns across this document and suggest connections. What would you like me to explore?`;
  }
  
  return `Hello! I'm ${agent.name}. How can I help?`;
}

async function generateSummary(doc, blockId) {
  if (blockId) {
    const block = doc.blocks.find(b => b.id === blockId);
    if (block) {
      return `Summary of "${block.content.substring(0, 30)}...":\n\nThis ${block.type} has ${block.replies?.length || 0} replies discussing key points and next steps.`;
    }
  }
  
  const headings = doc.blocks.filter(b => b.type === 'heading').map(b => b.content);
  const tasks = doc.blocks.filter(b => b.type === 'task');
  const completedTasks = tasks.filter(t => t.checked).length;
  
  return `📊 **Document Overview**\n\n• Sections: ${headings.join(', ')}\n• Tasks: ${completedTasks}/${tasks.length} completed\n• Total discussions: ${doc.blocks.reduce((sum, b) => sum + (b.replies?.length || 0), 0)}`;
}

async function generateStructure(doc) {
  return `📝 **Suggested Structure**\n\n1. **Executive Summary** (new heading)\n2. **Current Sections** (keep existing headings)\n3. **Action Items** (consolidate all tasks)\n4. **Discussion Log** (move discussion blocks here)\n5. **Appendix** (for reference materials)`;
}

async function extractTasks(doc) {
  const existingTasks = doc.blocks.filter(b => b.type === 'task');
  const discussions = doc.blocks.filter(b => b.type === 'discussion');
  
  return `✅ **Task Analysis**\n\nFound ${existingTasks.length} explicit tasks.\nFrom discussions, I identified potential tasks:\n• Follow up on mobile app priorities\n• Schedule architecture review\n• Create user research plan`;
}

function sendToClient(clientId, data) {
  const client = clients.get(clientId);
  if (client && client.ws.readyState === 1) {
    client.ws.send(JSON.stringify(data));
  }
}

function broadcastToDoc(docId, data, excludeClientId = null) {
  for (const [clientId, client] of clients) {
    if (clientId !== excludeClientId && 
        client.currentDoc === docId && 
        client.ws.readyState === 1) {
      client.ws.send(JSON.stringify(data));
    }
  }
}

server.listen(PORT, () => {
  console.log(`🔄 LoopDoc server running on http://localhost:${PORT}`);
  console.log(`📄 Documents: ${documents.size}`);
  console.log(`🤖 Agents: ${agents.size}`);
});
