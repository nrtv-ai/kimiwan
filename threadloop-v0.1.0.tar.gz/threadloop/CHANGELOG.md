# ThreadLoop Changelog

## [0.1.0] - 2025-02-23

### Added
- Initial prototype release
- WebSocket-based real-time messaging
- Three built-in agents: Claude, CodeBot, ResearchBot
- Agent mention system (@Claude, @CodeBot, @ResearchBot)
- Thread-based conversation channels
- Dark mode UI with modern design
- Typing indicators
- Create new channels
- Simulated agent responses

### Technical
- Node.js + WebSocket server
- Vanilla JavaScript frontend
- In-memory storage (non-persistent)
