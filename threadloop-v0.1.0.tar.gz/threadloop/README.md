# ThreadLoop 🔄

> An AI-native messenger for human-agent collaboration

ThreadLoop is a messaging platform where humans and AI agents collaborate as equals. Unlike traditional chatbots that respond to commands, agents in ThreadLoop are first-class participants with persistent identity, memory, and the ability to take actions within conversations.

![Version](https://img.shields.io/badge/version-0.1.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)

## 🌟 Vision

The future of work is human-agent collaboration. Current messaging platforms treat AI as an afterthought—bots that respond to slash commands or @mentions in isolated interactions. ThreadLoop reimagines messaging from the ground up for a world where:

- **Agents are team members** with persistent identity and memory
- **Conversations are collaborative** between humans and agents
- **Context is shared** across the entire thread history
- **Actions happen in context**—agents don't just chat, they *do* things

## 🚀 Features

### Current (v0.1.0 - Prototype)

- ✅ **Real-time messaging** via WebSocket
- ✅ **Agent participants** - Three built-in agents (Claude, CodeBot, ResearchBot)
- ✅ **Agent mentions** - @mention agents to get their assistance
- ✅ **Thread-based conversations** - Organized channels
- ✅ **Persistent message history** - Per-thread message storage
- ✅ **Typing indicators** - See when participants are typing
- ✅ **Dark mode UI** - Modern, clean interface

### Agents

| Agent | Avatar | Capabilities | Personality |
|-------|--------|--------------|-------------|
| **Claude** | 🤖 | Chat, Summarize, Analyze | Helpful, thoughtful AI assistant |
| **CodeBot** | 👨‍💻 | Code, Review, Debug | Expert programmer, concise and technical |
| **ResearchBot** | 🔬 | Search, Analyze, Synthesize | Thorough researcher, asks clarifying questions |

### Coming Soon

- [ ] **Agent memory** - Agents remember conversations across sessions
- [ ] **Agent-to-agent messaging** - Agents can collaborate with each other
- [ ] **Action system** - Agents can execute tasks (summarize, search, code review)
- [ ] **File attachments** - Share files in conversations
- [ ] **Thread search** - Search message history
- [ ] **Direct messages** - 1:1 conversations
- [ ] **Agent customization** - Add your own agents with custom capabilities
- [ ] **LLM integration** - Connect to real LLM APIs (OpenAI, Anthropic, etc.)
- [ ] **Persistent storage** - Database backend (currently in-memory)

## 🛠️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        ThreadLoop                            │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   Web UI    │  │   WebSocket │  │   Agent Engine      │  │
│  │  (React)    │  │   Server    │  │  (Simulated LLMs)   │  │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘  │
│         │                │                    │             │
│         └────────────────┼────────────────────┘             │
│                          │                                  │
│                   ┌──────┴──────┐                          │
│                   │   Memory    │                          │
│                   │   Layer     │                          │
│                   │ (In-Memory) │                          │
│                   └─────────────┘                          │
└─────────────────────────────────────────────────────────────┘
```

### Core Components

1. **WebSocket Server** (`server.js`)
   - Handles real-time bidirectional communication
   - Routes messages between clients
   - Manages thread state and agent interactions

2. **Client Application** (`public/app.js`)
   - Modern dark-mode UI
   - Real-time message updates
   - Agent mention detection

3. **Agent System** (in `server.js`)
   - Agent definitions with capabilities
   - Simple response generation (simulated)
   - Action execution framework

## 🚀 Quick Start

### Prerequisites

- Node.js 18+
- npm or yarn

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/threadloop.git
cd threadloop

# Install dependencies
npm install

# Start the server
npm run dev
```

Open http://localhost:3000 in your browser.

### Usage

1. **Join a channel** - Click on #General or create a new channel
2. **Send messages** - Type in the input box and press Enter
3. **Mention an agent** - Type `@Claude`, `@CodeBot`, or `@ResearchBot` followed by your request
4. **Watch agents respond** - Agents will respond after a brief "thinking" delay

Example messages:
- "@Claude can you summarize this conversation?"
- "@CodeBot help me write a function to handle WebSocket messages"
- "@ResearchBot what do we know about this topic so far?"

## 🗺️ Roadmap

### Phase 1: Foundation (Current)
- [x] Basic messaging infrastructure
- [x] Simulated agent responses
- [x] Thread management

### Phase 2: Agent Intelligence
- [ ] Integrate real LLM APIs (OpenAI, Anthropic)
- [ ] Agent memory and context awareness
- [ ] Agent-to-agent communication
- [ ] Action system (agents can execute tasks)

### Phase 3: Collaboration Features
- [ ] File sharing and attachments
- [ ] Thread search
- [ ] Message reactions
- [ ] Thread pinning

### Phase 4: Scale & Deploy
- [ ] Database persistence (PostgreSQL/MongoDB)
- [ ] Authentication & user management
- [ ] Docker deployment
- [ ] Self-hosting documentation

## 🤔 Why ThreadLoop?

### The Problem

Current AI assistants are:
- **Ephemeral** - They don't remember past conversations
- **Isolated** - Each interaction starts from scratch
- **Reactive** - They wait for commands rather than participating
- **Limited** - They can't take actions in the real world

### The Solution

ThreadLoop treats agents as:
- **Persistent** - They have memory across sessions
- **Collaborative** - They participate in ongoing discussions
- **Proactive** - They can suggest ideas and take initiative
- **Capable** - They can execute actions and report results

### Use Cases

1. **Software Development**
   - CodeBot reviews PRs in the team channel
   - Agents suggest refactoring opportunities
   - Documentation is updated automatically

2. **Research & Analysis**
   - ResearchBot monitors news and summarizes for the team
   - Agents debate different approaches
   - Findings are compiled into reports

3. **Project Management**
   - Agents track task progress
   - Reminders and blockers are surfaced automatically
   - Standup summaries are generated

4. **Creative Collaboration**
   - Brainstorming with AI partners
   - Iterative refinement of ideas
   - Agents provide diverse perspectives

## 🏗️ Technical Decisions

### Why WebSocket?
WebSocket provides true bidirectional communication essential for real-time collaboration. Unlike HTTP polling, it enables instant message delivery and typing indicators.

### Why File-Based Memory?
Following OpenClaw's philosophy, ThreadLoop uses a file-based approach for memory. This makes it:
- Transparent (you can read what agents remember)
- Version-controllable (git works naturally)
- Portable (no database dependencies)
- Debuggable (inspect files directly)

### Why Simulated Agents?
The current prototype uses simulated agent responses to demonstrate the architecture. In production, this would connect to real LLM APIs while maintaining the same participant model.

## 🤝 Contributing

ThreadLoop is in early development. Contributions are welcome!

### Areas for Contribution

- [ ] LLM integration (OpenAI, Anthropic, local models)
- [ ] Additional agent capabilities
- [ ] UI/UX improvements
- [ ] Testing infrastructure
- [ ] Documentation

### Development Setup

```bash
# Fork and clone
git clone https://github.com/yourusername/threadloop.git
cd threadloop

# Install dependencies
npm install

# Run in development mode
npm run dev
```

## 📄 License

MIT License - see LICENSE file for details.

## 🙏 Acknowledgments

- Inspired by [OpenClaw](https://github.com/OpenClaw) and its approach to persistent AI agents
- UI design inspired by Discord and Slack
- Block-based editor research informed by [BlockNote](https://www.blocknotejs.org/) and [AFFiNE](https://affine.pro/)

## 🔮 The Future

ThreadLoop aims to define what human-agent collaboration looks like. As AI agents become more capable, the platforms we use to work with them need to evolve. ThreadLoop is an experiment in that evolution—a space where humans and agents can truly collaborate as peers.

---

**Built with ❤️ for the future of work.**
