import { WebSocketServer } from 'ws';
import { v4 as uuidv4 } from 'uuid';
import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;

// In-memory storage (would be a database in production)
const threads = new Map();
const participants = new Map();
const messages = new Map();

// Agent definitions
const agents = new Map([
  ['claude', {
    id: 'claude',
    name: 'Claude',
    type: 'agent',
    avatar: '🤖',
    capabilities: ['chat', 'summarize', 'analyze'],
    status: 'online',
    personality: 'Helpful, thoughtful AI assistant'
  }],
  ['coder', {
    id: 'coder',
    name: 'CodeBot',
    type: 'agent',
    avatar: '👨‍💻',
    capabilities: ['code', 'review', 'debug'],
    status: 'online',
    personality: 'Expert programmer, concise and technical'
  }],
  ['researcher', {
    id: 'researcher',
    name: 'ResearchBot',
    type: 'agent',
    avatar: '🔬',
    capabilities: ['search', 'analyze', 'synthesize'],
    status: 'away',
    personality: 'Thorough researcher, asks clarifying questions'
  }]
]);

// Initialize with sample thread
const sampleThreadId = uuidv4();
threads.set(sampleThreadId, {
  id: sampleThreadId,
  name: 'General',
  type: 'channel',
  createdAt: new Date().toISOString(),
  participants: ['claude', 'coder'],
  messageCount: 0
});

// HTTP server for serving static files
const server = http.createServer((req, res) => {
  let filePath = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url);
  
  const ext = path.extname(filePath);
  const contentTypes = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json'
  };
  
  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Not Found');
      } else {
        res.writeHead(500);
        res.end('Server Error');
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentTypes[ext] || 'text/plain' });
      res.end(content);
    }
  });
});

// WebSocket server
const wss = new WebSocketServer({ server });

// Connected clients
const clients = new Map();

wss.on('connection', (ws, req) => {
  const clientId = uuidv4();
  console.log(`Client connected: ${clientId}`);
  
  clients.set(clientId, {
    ws,
    id: clientId,
    user: null,
    currentThread: null
  });

  // Send initial data
  ws.send(JSON.stringify({
    type: 'init',
    data: {
      clientId,
      threads: Array.from(threads.values()),
      agents: Array.from(agents.values())
    }
  }));

  ws.on('message', async (data) => {
    try {
      const msg = JSON.parse(data);
      await handleMessage(clientId, msg);
    } catch (err) {
      console.error('Message handling error:', err);
      sendToClient(clientId, {
        type: 'error',
        error: err.message
      });
    }
  });

  ws.on('close', () => {
    console.log(`Client disconnected: ${clientId}`);
    clients.delete(clientId);
  });
});

async function handleMessage(clientId, msg) {
  const client = clients.get(clientId);
  
  switch (msg.type) {
    case 'auth':
      // Simple auth - just set user info
      client.user = {
        id: msg.userId || uuidv4(),
        name: msg.name || 'Anonymous',
        type: 'human',
        avatar: msg.avatar || '👤'
      };
      participants.set(client.user.id, client.user);
      
      broadcast({
        type: 'user_joined',
        user: client.user
      });
      break;

    case 'join_thread':
      client.currentThread = msg.threadId;
      const threadMessages = getThreadMessages(msg.threadId);
      
      sendToClient(clientId, {
        type: 'thread_history',
        threadId: msg.threadId,
        messages: threadMessages
      });
      
      // Notify others
      broadcastToThread(msg.threadId, {
        type: 'participant_joined',
        threadId: msg.threadId,
        participant: client.user
      }, clientId);
      break;

    case 'send_message':
      const message = {
        id: uuidv4(),
        threadId: msg.threadId,
        authorId: client.user.id,
        author: client.user,
        content: msg.content,
        timestamp: new Date().toISOString(),
        type: 'message'
      };
      
      storeMessage(message);
      
      // Update thread message count
      const thread = threads.get(msg.threadId);
      if (thread) {
        thread.messageCount++;
        thread.lastMessageAt = message.timestamp;
      }
      
      // Broadcast to all in thread
      broadcastToThread(msg.threadId, {
        type: 'new_message',
        message
      });
      
      // Trigger agent responses if mentioned
      await handleAgentMentions(msg.threadId, message);
      break;

    case 'create_thread':
      const newThread = {
        id: uuidv4(),
        name: msg.name,
        type: msg.threadType || 'channel',
        createdAt: new Date().toISOString(),
        participants: [client.user.id],
        messageCount: 0
      };
      threads.set(newThread.id, newThread);
      
      broadcast({
        type: 'thread_created',
        thread: newThread
      });
      break;

    case 'agent_action':
      // Handle agent taking an action
      await executeAgentAction(msg.agentId, msg.action, msg.params, msg.threadId);
      break;

    case 'typing':
      broadcastToThread(msg.threadId, {
        type: 'typing',
        threadId: msg.threadId,
        participant: client.user
      }, clientId);
      break;
  }
}

async function handleAgentMentions(threadId, message) {
  const content = message.content.toLowerCase();
  
  for (const [agentId, agent] of agents) {
    if (content.includes(`@${agentId}`) || content.includes(`@${agent.name.toLowerCase()}`)) {
      // Simulate agent thinking and responding
      setTimeout(async () => {
        const response = await generateAgentResponse(agent, message, threadId);
        
        const agentMessage = {
          id: uuidv4(),
          threadId,
          authorId: agent.id,
          author: agent,
          content: response,
          timestamp: new Date().toISOString(),
          type: 'message',
          metadata: { agentGenerated: true }
        };
        
        storeMessage(agentMessage);
        
        broadcastToThread(threadId, {
          type: 'new_message',
          message: agentMessage
        });
      }, 1000 + Math.random() * 2000);
    }
  }
}

async function generateAgentResponse(agent, userMessage, threadId) {
  const content = userMessage.content.toLowerCase();
  const threadMessages = getThreadMessages(threadId);
  const context = threadMessages.slice(-5).map(m => `${m.author.name}: ${m.content}`).join('\n');
  
  // Simple response generation based on agent type
  if (agent.id === 'claude') {
    if (content.includes('summarize')) {
      return `📋 **Summary of recent conversation:**\n\nBased on the last ${threadMessages.length} messages, the discussion has been about various topics. Key points include user questions and collaborative responses.`;
    }
    if (content.includes('help')) {
      return `I'm here to help! I can:\n• Answer questions\n• Summarize conversations\n• Collaborate on ideas\n\nWhat would you like to work on?`;
    }
    return `Thanks for reaching out! I see the conversation context. How can I assist you today?`;
  }
  
  if (agent.id === 'coder') {
    if (content.includes('code') || content.includes('function') || content.includes('bug')) {
      return `\`\`\`javascript
// Example code suggestion
function handleMessage(msg) {
  if (msg.type === 'agent_action') {
    return executeAction(msg);
  }
  return processNormally(msg);
}
\`\`\`\n\nWould you like me to explain this or help with something specific?`;
    }
    return `I can help with coding tasks, reviews, or debugging. What are you working on?`;
  }
  
  if (agent.id === 'researcher') {
    return `🔍 I can help research that topic. Let me analyze the context and gather relevant information...`;
  }
  
  return `Hello! I'm ${agent.name}. How can I assist?`;
}

async function executeAgentAction(agentId, action, params, threadId) {
  const agent = agents.get(agentId);
  if (!agent) return;
  
  let result;
  
  switch (action) {
    case 'summarize_thread':
      const msgs = getThreadMessages(threadId);
      result = `Summarized ${msgs.length} messages in this thread.`;
      break;
    case 'search_history':
      result = `Found 3 relevant messages matching "${params.query}".`;
      break;
    default:
      result = `Action "${action}" completed.`;
  }
  
  const actionMessage = {
    id: uuidv4(),
    threadId,
    authorId: agent.id,
    author: agent,
    content: `✅ **Action Result:** ${result}`,
    timestamp: new Date().toISOString(),
    type: 'action_result',
    metadata: { action, params, result }
  };
  
  storeMessage(actionMessage);
  
  broadcastToThread(threadId, {
    type: 'new_message',
    message: actionMessage
  });
}

function storeMessage(message) {
  if (!messages.has(message.threadId)) {
    messages.set(message.threadId, []);
  }
  messages.get(message.threadId).push(message);
}

function getThreadMessages(threadId) {
  return messages.get(threadId) || [];
}

function sendToClient(clientId, data) {
  const client = clients.get(clientId);
  if (client && client.ws.readyState === 1) {
    client.ws.send(JSON.stringify(data));
  }
}

function broadcast(data, excludeClientId = null) {
  for (const [clientId, client] of clients) {
    if (clientId !== excludeClientId && client.ws.readyState === 1) {
      client.ws.send(JSON.stringify(data));
    }
  }
}

function broadcastToThread(threadId, data, excludeClientId = null) {
  for (const [clientId, client] of clients) {
    if (clientId !== excludeClientId && 
        client.currentThread === threadId && 
        client.ws.readyState === 1) {
      client.ws.send(JSON.stringify(data));
    }
  }
}

server.listen(PORT, () => {
  console.log(`🚀 ThreadLoop server running on http://localhost:${PORT}`);
  console.log(`📱 WebSocket server ready for connections`);
});
