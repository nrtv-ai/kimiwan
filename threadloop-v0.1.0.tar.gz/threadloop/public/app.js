// ThreadLoop Client Application

const state = {
  ws: null,
  clientId: null,
  user: null,
  currentThread: null,
  threads: [],
  agents: [],
  messages: [],
  typingTimeout: null
};

// DOM Elements
const elements = {
  threadList: document.getElementById('thread-list'),
  agentList: document.getElementById('agent-list'),
  messagesContainer: document.getElementById('messages-container'),
  messageInput: document.getElementById('message-input'),
  sendBtn: document.getElementById('send-btn'),
  currentThreadName: document.getElementById('current-thread-name'),
  threadParticipants: document.getElementById('thread-participants'),
  userInfo: document.getElementById('user-info'),
  newThreadBtn: document.getElementById('new-thread-btn'),
  newThreadModal: document.getElementById('new-thread-modal'),
  newThreadNameInput: document.getElementById('new-thread-name'),
  createThreadBtn: document.getElementById('create-thread'),
  cancelThreadBtn: document.getElementById('cancel-thread'),
  summarizeBtn: document.getElementById('summarize-btn')
};

// Initialize
function init() {
  connectWebSocket();
  setupEventListeners();
  generateUser();
}

function generateUser() {
  const names = ['Alex', 'Jordan', 'Taylor', 'Morgan', 'Casey', 'Riley'];
  const avatars = ['👤', '🧑', '👩', '🧔', '👱', '🧑‍🦱'];
  const randomIdx = Math.floor(Math.random() * names.length);
  
  state.user = {
    id: `user_${Date.now()}`,
    name: names[randomIdx],
    avatar: avatars[randomIdx]
  };
  
  updateUserInfo();
}

function updateUserInfo() {
  elements.userInfo.innerHTML = `
    <span class="avatar">${state.user.avatar}</span>
    <span class="name">${state.user.name}</span>
  `;
}

// WebSocket Connection
function connectWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}`;
  
  state.ws = new WebSocket(wsUrl);
  
  state.ws.onopen = () => {
    console.log('Connected to ThreadLoop');
    
    // Authenticate
    sendMessage({
      type: 'auth',
      userId: state.user.id,
      name: state.user.name,
      avatar: state.user.avatar
    });
  };
  
  state.ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    handleServerMessage(msg);
  };
  
  state.ws.onclose = () => {
    console.log('Disconnected from ThreadLoop');
    setTimeout(connectWebSocket, 3000);
  };
  
  state.ws.onerror = (error) => {
    console.error('WebSocket error:', error);
  };
}

function sendMessage(data) {
  if (state.ws && state.ws.readyState === WebSocket.OPEN) {
    state.ws.send(JSON.stringify(data));
  }
}

// Message Handlers
function handleServerMessage(msg) {
  switch (msg.type) {
    case 'init':
      state.clientId = msg.data.clientId;
      state.threads = msg.data.threads;
      state.agents = msg.data.agents;
      renderThreads();
      renderAgents();
      
      // Auto-join first thread
      if (state.threads.length > 0) {
        joinThread(state.threads[0].id);
      }
      break;
      
    case 'thread_history':
      state.messages = msg.messages;
      renderMessages();
      break;
      
    case 'new_message':
      if (msg.message.threadId === state.currentThread) {
        addMessage(msg.message);
      }
      break;
      
    case 'thread_created':
      state.threads.push(msg.thread);
      renderThreads();
      break;
      
    case 'user_joined':
      console.log('User joined:', msg.user);
      break;
      
    case 'participant_joined':
      showSystemMessage(`${msg.participant.name} joined the channel`);
      break;
      
    case 'typing':
      showTypingIndicator(msg.participant);
      break;
      
    case 'error':
      console.error('Server error:', msg.error);
      break;
  }
}

// Thread Management
function joinThread(threadId) {
  state.currentThread = threadId;
  
  const thread = state.threads.find(t => t.id === threadId);
  if (thread) {
    elements.currentThreadName.textContent = `# ${thread.name}`;
    elements.threadParticipants.textContent = `${thread.participants?.length || 0} participants`;
  }
  
  // Update active state in sidebar
  document.querySelectorAll('.thread-item').forEach(el => {
    el.classList.toggle('active', el.dataset.id === threadId);
  });
  
  // Clear and show loading
  elements.messagesContainer.innerHTML = `
    <div class="welcome-message">
      <p>Loading messages...</p>
    </div>
  `;
  
  sendMessage({
    type: 'join_thread',
    threadId
  });
}

function createThread(name) {
  sendMessage({
    type: 'create_thread',
    name,
    threadType: 'channel'
  });
}

// Rendering
function renderThreads() {
  elements.threadList.innerHTML = state.threads.map(thread => `
    <li class="thread-item ${thread.id === state.currentThread ? 'active' : ''}" 
        data-id="${thread.id}"
        onclick="joinThread('${thread.id}')">
      <span class="icon">#</span>
      <span class="name">${escapeHtml(thread.name)}</span>
      ${thread.messageCount > 0 ? `<span class="count">${thread.messageCount}</span>` : ''}
    </li>
  `).join('');
}

function renderAgents() {
  elements.agentList.innerHTML = state.agents.map(agent => `
    <li class="agent-item" title="${agent.personality}">
      <span class="avatar">${agent.avatar}</span>
      <div class="info">
        <span class="name">${escapeHtml(agent.name)}</span>
        <span class="status">
          <span class="status-dot ${agent.status}"></span>
          ${agent.status}
        </span>
      </div>
    </li>
  `).join('');
}

function renderMessages() {
  if (state.messages.length === 0) {
    elements.messagesContainer.innerHTML = `
      <div class="welcome-message">
        <p>No messages yet. Start the conversation!</p>
        <p style="margin-top: 16px; font-size: 0.9rem;">Try mentioning an agent: @Claude, @CodeBot, or @ResearchBot</p>
      </div>
    `;
    return;
  }
  
  elements.messagesContainer.innerHTML = state.messages.map(msg => formatMessage(msg)).join('');
  scrollToBottom();
}

function addMessage(message) {
  const html = formatMessage(message);
  
  // Remove welcome message if present
  const welcome = elements.messagesContainer.querySelector('.welcome-message');
  if (welcome) {
    welcome.remove();
  }
  
  // Remove typing indicator if from same author
  const typing = elements.messagesContainer.querySelector('.typing-indicator');
  if (typing) {
    typing.remove();
  }
  
  elements.messagesContainer.insertAdjacentHTML('beforeend', html);
  scrollToBottom();
}

function formatMessage(msg) {
  const isAgent = msg.author?.type === 'agent';
  const time = new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const content = formatContent(msg.content);
  
  return `
    <div class="message" data-id="${msg.id}">
      <span class="avatar">${msg.author?.avatar || '👤'}</span>
      <div class="content">
        <div class="header">
          <span class="author ${isAgent ? 'agent' : ''}">${escapeHtml(msg.author?.name || 'Unknown')}</span>
          ${isAgent ? '<span class="badge">Agent</span>' : ''}
          <span class="timestamp">${time}</span>
        </div>
        <div class="text">${content}</div>
      </div>
    </div>
  `;
}

function formatContent(content) {
  // Simple markdown-like formatting
  return escapeHtml(content)
    .replace(/```(\w+)?\n([\s\S]*?)```/g, '<pre><code>$2</code></pre>')
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/@(\w+)/g, '<span style="color: var(--accent-primary); cursor: pointer;">@$1</span>')
    .replace(/\n/g, '<br>');
}

function showSystemMessage(text) {
  const html = `
    <div class="message" style="opacity: 0.7;">
      <span class="avatar">🔔</span>
      <div class="content">
        <div class="text" style="font-style: italic; color: var(--text-muted);">${escapeHtml(text)}</div>
      </div>
    </div>
  `;
  elements.messagesContainer.insertAdjacentHTML('beforeend', html);
  scrollToBottom();
}

function showTypingIndicator(participant) {
  // Remove existing typing indicator
  const existing = elements.messagesContainer.querySelector('.typing-indicator');
  if (existing) existing.remove();
  
  const html = `
    <div class="typing-indicator">
      <span class="avatar" style="font-size: 1.5rem;">${participant.avatar}</span>
      <span>${participant.name} is typing</span>
      <span class="dots">
        <span class="dot"></span>
        <span class="dot"></span>
        <span class="dot"></span>
      </span>
    </div>
  `;
  
  elements.messagesContainer.insertAdjacentHTML('beforeend', html);
  scrollToBottom();
  
  // Remove after 3 seconds
  setTimeout(() => {
    const indicator = elements.messagesContainer.querySelector('.typing-indicator');
    if (indicator) indicator.remove();
  }, 3000);
}

function scrollToBottom() {
  elements.messagesContainer.scrollTop = elements.messagesContainer.scrollHeight;
}

function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Event Listeners
function setupEventListeners() {
  // Send message
  elements.sendBtn.addEventListener('click', sendCurrentMessage);
  
  elements.messageInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendCurrentMessage();
    }
    
    // Typing indicator
    if (state.typingTimeout) {
      clearTimeout(state.typingTimeout);
    }
    
    sendMessage({
      type: 'typing',
      threadId: state.currentThread
    });
    
    state.typingTimeout = setTimeout(() => {
      state.typingTimeout = null;
    }, 1000);
  });
  
  // Auto-resize textarea
  elements.messageInput.addEventListener('input', () => {
    elements.messageInput.style.height = 'auto';
    elements.messageInput.style.height = Math.min(elements.messageInput.scrollHeight, 200) + 'px';
  });
  
  // New thread modal
  elements.newThreadBtn.addEventListener('click', () => {
    elements.newThreadModal.classList.remove('hidden');
    elements.newThreadNameInput.focus();
  });
  
  elements.cancelThreadBtn.addEventListener('click', () => {
    elements.newThreadModal.classList.add('hidden');
    elements.newThreadNameInput.value = '';
  });
  
  elements.createThreadBtn.addEventListener('click', () => {
    const name = elements.newThreadNameInput.value.trim();
    if (name) {
      createThread(name);
      elements.newThreadModal.classList.add('hidden');
      elements.newThreadNameInput.value = '';
    }
  });
  
  elements.newThreadNameInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      elements.createThreadBtn.click();
    }
  });
  
  // Summarize button
  elements.summarizeBtn.addEventListener('click', () => {
    if (state.currentThread) {
      sendMessage({
        type: 'send_message',
        threadId: state.currentThread,
        content: '@Claude can you summarize this thread?'
      });
    }
  });
}

function sendCurrentMessage() {
  const content = elements.messageInput.value.trim();
  if (!content || !state.currentThread) return;
  
  sendMessage({
    type: 'send_message',
    threadId: state.currentThread,
    content
  });
  
  elements.messageInput.value = '';
  elements.messageInput.style.height = 'auto';
}

// Expose functions to global scope for onclick handlers
window.joinThread = joinThread;

// Start
init();
